import React, { useState, useEffect } from 'react';
import { 
  Maximize2, 
  Layers, 
  TrendingUp, 
  TrendingDown, 
  Crosshair, 
  RefreshCw, 
  ShieldAlert, 
  Zap, 
  ChevronRight, 
  CheckCircle2, 
  Compass, 
  ArrowUpRight, 
  ArrowDownRight, 
  Info, 
  Clock, 
  Sliders, 
  Sparkles,
  BarChart2
} from 'lucide-react';
import { CRTLogic, CRT_SUPPORTED_ASSETS } from '../services/crtLogic';
import { CRTTimeframe, CRTMultiTFAnalysis, CRTCandleMarking } from '../types';

export const CRTStrategy: React.FC = () => {
  const [selectedSymbol, setSelectedSymbol] = useState<string>('NIFTY');
  const [selectedTF, setSelectedTF] = useState<CRTTimeframe | 'ALL'>('ALL');
  const [analysis, setAnalysis] = useState<CRTMultiTFAnalysis | null>(null);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'VISUAL_RANGES' | 'SIGNALS' | 'CONFLUENCE_MATRIX'>('VISUAL_RANGES');

  const refreshData = () => {
    setIsRefreshing(true);
    const result = CRTLogic.analyzeAsset(selectedSymbol);
    setAnalysis(result);
    setTimeout(() => setIsRefreshing(false), 400);
  };

  useEffect(() => {
    refreshData();
  }, [selectedSymbol]);

  if (!analysis) return null;

  const timeframes: CRTTimeframe[] = ['MONTHLY', 'WEEKLY', 'DAILY', '4H', '1H'];
  const displayedTimeframes = selectedTF === 'ALL' ? timeframes : [selectedTF];

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner & Control Deck */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 relative overflow-hidden backdrop-blur-xl shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 blur-[100px] rounded-full pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-emerald-500/10 blur-[100px] rounded-full pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 shadow-lg shadow-indigo-600/20">
              <Maximize2 size={28} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl lg:text-3xl font-black uppercase tracking-tight text-white flex items-center gap-3">
                  CRT Strategy
                  <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                    Candle Range Theory
                  </span>
                </h1>
              </div>
              <p className="text-xs lg:text-sm text-slate-400 mt-1 max-w-2xl leading-relaxed">
                Institutional Multi-Timeframe Candle Marking System. Real-time Highs, Lows, 50% Equilibrium, and Liquidity Sweep detection across <strong className="text-slate-200">Monthly, Weekly, Daily, 4H, and 1H</strong> timeframes.
              </p>
            </div>
          </div>

          {/* Symbol Selector & Refresh */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex bg-slate-950/80 p-1 rounded-2xl border border-slate-800">
              {CRT_SUPPORTED_ASSETS.map((asset) => (
                <button
                  key={asset.symbol}
                  onClick={() => setSelectedSymbol(asset.symbol)}
                  className={`px-3 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all ${
                    selectedSymbol === asset.symbol
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  {asset.symbol}
                </button>
              ))}
            </div>

            <button
              onClick={refreshData}
              disabled={isRefreshing}
              className="p-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-2xl border border-slate-700 transition-all active:scale-95 flex items-center justify-center"
              title="Refresh CRT Scan"
            >
              <RefreshCw size={18} className={isRefreshing ? 'animate-spin text-indigo-400' : ''} />
            </button>
          </div>
        </div>

        {/* Global Confluence Indicator Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-800/80 relative z-10">
          <div className="bg-slate-950/60 border border-slate-800 p-3.5 rounded-2xl">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block">Index Spot Price</span>
            <div className="text-lg font-black font-mono text-white mt-0.5">
              ₹{analysis.currentPrice.toLocaleString('en-IN')}
            </div>
          </div>

          <div className="bg-slate-950/60 border border-slate-800 p-3.5 rounded-2xl">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block">Confluent 5-TF Bias</span>
            <div className="flex items-center gap-1.5 mt-0.5">
              {analysis.confluentBias.includes('BULLISH') ? (
                <>
                  <TrendingUp size={16} className="text-emerald-400" />
                  <span className="text-xs font-black text-emerald-400 tracking-wide">{analysis.confluentBias.replace('_', ' ')}</span>
                </>
              ) : analysis.confluentBias.includes('BEARISH') ? (
                <>
                  <TrendingDown size={16} className="text-rose-400" />
                  <span className="text-xs font-black text-rose-400 tracking-wide">{analysis.confluentBias.replace('_', ' ')}</span>
                </>
              ) : (
                <>
                  <Compass size={16} className="text-amber-400" />
                  <span className="text-xs font-black text-amber-400 tracking-wide">RANGE EQUILIBRIUM</span>
                </>
              )}
            </div>
          </div>

          <div className="bg-slate-950/60 border border-slate-800 p-3.5 rounded-2xl">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block">Active CRT Signals</span>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="w-2 h-2 rounded-full bg-indigo-500 animate-ping" />
              <span className="text-xs font-black text-indigo-300 font-mono">
                {analysis.activeSignals.length} Institutional Setups
              </span>
            </div>
          </div>

          <div className="bg-slate-950/60 border border-slate-800 p-3.5 rounded-2xl">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block">Timeframes Monitored</span>
            <div className="text-xs font-bold font-mono text-slate-300 mt-0.5">
              Monthly • Weekly • Daily • 4H • 1H
            </div>
          </div>
        </div>
      </div>

      {/* Navigation View Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        {/* View Tabs */}
        <div className="flex bg-slate-900 p-1.5 rounded-2xl border border-slate-800">
          <button
            onClick={() => setActiveTab('VISUAL_RANGES')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all ${
              activeTab === 'VISUAL_RANGES'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Layers size={15} /> Visual Candle Ranges
          </button>
          <button
            onClick={() => setActiveTab('SIGNALS')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all relative ${
              activeTab === 'SIGNALS'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Zap size={15} /> Active Signals ({analysis.activeSignals.length})
          </button>
          <button
            onClick={() => setActiveTab('CONFLUENCE_MATRIX')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all ${
              activeTab === 'CONFLUENCE_MATRIX'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <BarChart2 size={15} /> 5-TF Confluence Matrix
          </button>
        </div>

        {/* Timeframe Filter for Visual Ranges */}
        {activeTab === 'VISUAL_RANGES' && (
          <div className="flex items-center gap-1.5 bg-slate-900 p-1.5 rounded-2xl border border-slate-800">
            <span className="text-[10px] font-bold text-slate-500 uppercase px-2">Filter:</span>
            {(['ALL', 'MONTHLY', 'WEEKLY', 'DAILY', '4H', '1H'] as const).map((tf) => (
              <button
                key={tf}
                onClick={() => setSelectedTF(tf)}
                className={`px-3 py-1.5 rounded-xl text-[11px] font-bold uppercase transition-all ${
                  selectedTF === tf
                    ? 'bg-slate-700 text-white border border-slate-600'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tf}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* TAB 1: VISUAL CANDLE RANGES */}
      {activeTab === 'VISUAL_RANGES' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayedTimeframes.map((tf) => {
            const marking = analysis.markings[tf];
            return <CRTCandleCard key={tf} marking={marking} currentPrice={analysis.currentPrice} />;
          })}
        </div>
      )}

      {/* TAB 2: ACTIVE CRT SIGNALS */}
      {activeTab === 'SIGNALS' && (
        <div className="space-y-4">
          {analysis.activeSignals.length === 0 ? (
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center text-slate-400">
              <Crosshair size={36} className="mx-auto mb-3 text-slate-600" />
              <h3 className="text-base font-bold text-white uppercase tracking-tight">No Active Sweep Setup Triggered</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                Candle ranges are currently in fair-value equilibrium without extreme High/Low liquidity sweeps on monitored timeframes.
              </p>
            </div>
          ) : (
            analysis.activeSignals.map((signal, idx) => (
              <div
                key={idx}
                className="bg-slate-900 border border-slate-800 hover:border-indigo-500/40 rounded-3xl p-6 transition-all relative overflow-hidden group shadow-lg"
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                  <div>
                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      <span className={`text-[10px] font-black uppercase px-2.5 py-1 rounded-lg ${
                        signal.type.includes('BUY') 
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                          : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                      }`}>
                        {signal.type.replace('_', ' ')}
                      </span>
                      <span className="text-[10px] font-black uppercase px-2.5 py-1 rounded-lg bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                        {signal.timeframe} CRT
                      </span>
                      <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                        Win Rate: {signal.confidence}%
                      </span>
                    </div>

                    <h3 className="text-lg font-bold text-white">{signal.title}</h3>
                    <p className="text-xs text-slate-400 mt-1 max-w-2xl leading-relaxed">{signal.description}</p>
                  </div>

                  {/* Level Metrics */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950/80 p-4 rounded-2xl border border-slate-800">
                    <div>
                      <span className="text-[9px] uppercase font-bold text-slate-500 block">Entry Point</span>
                      <span className="font-mono text-sm font-bold text-white">₹{signal.entry.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-[9px] uppercase font-bold text-rose-400 block">Stop Loss</span>
                      <span className="font-mono text-sm font-bold text-rose-400">₹{signal.stopLoss.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-[9px] uppercase font-bold text-emerald-400 block">TP1 (50% EQ)</span>
                      <span className="font-mono text-sm font-bold text-emerald-400">₹{signal.tp1.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-[9px] uppercase font-bold text-indigo-400 block">TP2 (Range Ext.)</span>
                      <span className="font-mono text-sm font-bold text-indigo-400">₹{signal.tp2.toLocaleString()}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* TAB 3: 5-TF CONFLUENCE MATRIX */}
      {activeTab === 'CONFLUENCE_MATRIX' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
          <div className="p-6 bg-slate-950/60 border-b border-slate-800">
            <h3 className="text-lg font-bold text-white uppercase tracking-tight flex items-center gap-2">
              <Compass size={18} className="text-indigo-400" />
              Multi-Timeframe Candle Range Alignment Matrix
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Live alignment across Monthly, Weekly, Daily, 4H, and 1H candles showing Premium vs Discount status.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800 font-bold">
                <tr>
                  <th className="px-6 py-4">Timeframe</th>
                  <th className="px-6 py-4">Candle Range (High - Low)</th>
                  <th className="px-6 py-4">50% Equilibrium (EQ)</th>
                  <th className="px-6 py-4">Current Zone</th>
                  <th className="px-6 py-4">Sweep Status</th>
                  <th className="px-6 py-4">CRT Bias</th>
                  <th className="px-6 py-4 text-right">Target Level</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 font-mono">
                {timeframes.map((tf) => {
                  const m = analysis.markings[tf];
                  return (
                    <tr key={tf} className="hover:bg-slate-800/40 transition-colors">
                      <td className="px-6 py-4 font-bold text-slate-200 flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-indigo-500" />
                        {tf}
                      </td>
                      <td className="px-6 py-4 text-slate-300">
                        {m.high.toLocaleString()} - {m.low.toLocaleString()}
                        <span className="text-[10px] text-slate-500 ml-1">({m.rangeSpan} pts)</span>
                      </td>
                      <td className="px-6 py-4 text-amber-400 font-bold">
                        {m.equilibrium.toLocaleString()}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded text-[10px] font-bold ${
                          m.zone === 'DISCOUNT' 
                            ? 'bg-emerald-500/20 text-emerald-400' 
                            : m.zone === 'PREMIUM'
                            ? 'bg-rose-500/20 text-rose-400'
                            : 'bg-amber-500/20 text-amber-400'
                        }`}>
                          {m.zone}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`text-[11px] font-bold ${
                          m.state === 'HIGH_SWEPT' 
                            ? 'text-rose-400' 
                            : m.state === 'LOW_SWEPT' 
                            ? 'text-emerald-400' 
                            : 'text-slate-400'
                        }`}>
                          {m.state.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`font-bold flex items-center gap-1 ${
                          m.bias === 'BULLISH' ? 'text-emerald-400' : 'text-rose-400'
                        }`}>
                          {m.bias === 'BULLISH' ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                          {m.bias}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right text-indigo-400 font-bold">
                        ₹{m.target1.toLocaleString()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Strategy Summary & Rules Banner */}
      <div className="bg-gradient-to-r from-indigo-950/40 via-slate-900 to-slate-900 border border-indigo-500/30 rounded-3xl p-6">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/20 flex items-center justify-center text-indigo-400 shrink-0">
            <Info size={20} />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">
              CRT Strategy Core Execution Rules:
            </h4>
            <ul className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs text-slate-300 mt-3">
              <li className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <strong className="text-indigo-400 block mb-1">1. Liquidity Sweep:</strong>
                High or Low of the candle (PMH/PML, PWH/PWL, PDH/PDL) must be swept by a wick.
              </li>
              <li className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <strong className="text-emerald-400 block mb-1">2. Range Rejection:</strong>
                Candle body must reject and close back inside the previous candle range.
              </li>
              <li className="bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <strong className="text-amber-400 block mb-1">3. The 50% Rule:</strong>
                Primary take profit target is always 50% Equilibrium (EQ), followed by range opposite extreme.
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

interface CRTCandleCardProps {
  marking: CRTCandleMarking;
  currentPrice: number;
}

const CRTCandleCard: React.FC<CRTCandleCardProps> = ({ marking, currentPrice }) => {
  // Calculate relative percent height for visual gauge (0% at Low, 100% at High)
  const range = marking.rangeSpan || 1;
  const currentRatio = Math.max(0, Math.min(100, ((currentPrice - marking.low) / range) * 100));
  const openRatio = Math.max(0, Math.min(100, ((marking.open - marking.low) / range) * 100));

  return (
    <div className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-3xl p-6 transition-all shadow-xl flex flex-col justify-between">
      <div>
        {/* Card Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider px-2 py-0.5 rounded-lg bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                {marking.timeframe}
              </span>
              <h3 className="text-sm font-bold text-white">{marking.periodLabel}</h3>
            </div>
            <span className="text-[10px] text-slate-500 font-mono mt-0.5 block">
              Range: {marking.rangeSpan} points
            </span>
          </div>

          <span className={`text-[10px] font-black uppercase px-2.5 py-1 rounded-lg ${
            marking.bias === 'BULLISH' 
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
              : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
          }`}>
            {marking.bias}
          </span>
        </div>

        {/* Visual Range Indicator Diagram */}
        <div className="my-6 bg-slate-950/80 rounded-2xl p-4 border border-slate-800">
          <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mb-2">
            <span className="text-rose-400 font-bold flex items-center gap-1">
              <span className="w-2 h-0.5 bg-rose-500 rounded" />
              {marking.highLabel}
            </span>
            <span className="font-bold text-white font-mono">₹{marking.high.toLocaleString()}</span>
          </div>

          {/* Candle Range Vertical Gauge */}
          <div className="relative h-28 w-full bg-slate-900 rounded-xl border border-slate-800 overflow-hidden my-2 flex items-center justify-center">
            {/* Premium / Discount Background split */}
            <div className="absolute top-0 inset-x-0 h-1/2 bg-rose-500/5" title="Premium Zone" />
            <div className="absolute bottom-0 inset-x-0 h-1/2 bg-emerald-500/5" title="Discount Zone" />

            {/* 50% Equilibrium Line */}
            <div className="absolute top-1/2 inset-x-0 border-b border-dashed border-amber-500/80 z-10 flex items-center justify-between px-3">
              <span className="text-[9px] font-bold font-mono text-amber-400 bg-slate-950/90 px-1.5 py-0.5 rounded">
                50% EQ: ₹{marking.equilibrium.toLocaleString()}
              </span>
              <span className="text-[8px] uppercase tracking-widest text-amber-500/80">Equilibrium</span>
            </div>

            {/* Candle Open Marker */}
            <div 
              className="absolute inset-x-0 border-b border-slate-500/50 z-10" 
              style={{ bottom: `${openRatio}%` }} 
            />

            {/* Current Price Pointer */}
            <div 
              className="absolute inset-x-0 z-20 flex items-center justify-end px-3 -translate-y-1/2 pointer-events-none"
              style={{ bottom: `${currentRatio}%` }}
            >
              <div className="flex items-center gap-1 bg-indigo-600 text-white text-[10px] font-mono font-black px-2 py-0.5 rounded-md shadow-lg shadow-indigo-600/40 border border-indigo-400 animate-pulse">
                <span>LIVE</span>
                <span>₹{currentPrice.toLocaleString()}</span>
              </div>
            </div>
          </div>

          <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mt-2">
            <span className="text-emerald-400 font-bold flex items-center gap-1">
              <span className="w-2 h-0.5 bg-emerald-500 rounded" />
              {marking.lowLabel}
            </span>
            <span className="font-bold text-white font-mono">₹{marking.low.toLocaleString()}</span>
          </div>
        </div>

        {/* Detailed Level Table */}
        <div className="space-y-2 text-xs font-mono">
          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950/50 border border-slate-800">
            <span className="text-slate-400 text-[11px]">Candle Open:</span>
            <span className="font-bold text-slate-200">₹{marking.open.toLocaleString()}</span>
          </div>
          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950/50 border border-slate-800">
            <span className="text-slate-400 text-[11px]">Active Zone:</span>
            <span className={`font-bold ${
              marking.zone === 'DISCOUNT' ? 'text-emerald-400' : 'text-rose-400'
            }`}>
              {marking.zone} ({currentRatio > 50 ? `+${(currentRatio - 50).toFixed(1)}%` : `-${(50 - currentRatio).toFixed(1)}%`})
            </span>
          </div>
          <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950/50 border border-slate-800">
            <span className="text-slate-400 text-[11px]">Sweep Status:</span>
            <span className={`font-bold ${
              marking.state === 'HIGH_SWEPT' 
                ? 'text-rose-400' 
                : marking.state === 'LOW_SWEPT' 
                ? 'text-emerald-400' 
                : 'text-slate-400'
            }`}>
              {marking.state.replace('_', ' ')}
            </span>
          </div>
        </div>
      </div>

      {/* Target Preview */}
      <div className="mt-4 pt-4 border-t border-slate-800 flex items-center justify-between text-[11px]">
        <span className="text-slate-400">CRT Target:</span>
        <span className="font-mono font-bold text-indigo-400">
          50% EQ @ ₹{marking.target1.toLocaleString()}
        </span>
      </div>
    </div>
  );
};
