
import React, { useEffect, useState } from 'react';
import { Layers, RefreshCw, Calendar, TrendingUp, TrendingDown, AlertCircle, BoxSelect, Filter, Clock } from 'lucide-react';
import { SmartMoneyLogic } from '../services/smartMoneyLogic';
import { SMCZone, SMCPatternType, Trend } from '../types';
import { ALL_INDICES } from '../services/dhanService';

const getBadgeColor = (pattern: SMCPatternType, trend: Trend) => {
    if (pattern === 'IFVG') return 'bg-purple-500/20 text-purple-400 border-purple-500/40';
    if (pattern === 'BOB') return 'bg-orange-500/20 text-orange-400 border-orange-500/40';
    
    if (trend === 'Bullish') return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40';
    return 'bg-rose-500/20 text-rose-400 border-rose-500/40';
};

const PatternBadge: React.FC<{ zone: SMCZone }> = ({ zone }) => (
    <div className={`flex flex-col border rounded-lg p-2 ${getBadgeColor(zone.pattern, zone.trend)}`}>
        <div className="flex justify-between items-center mb-1">
            <span className="font-bold text-xs">{zone.pattern}</span>
            <span className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded shadow-sm ${
                zone.timeframe === 'WEEKLY' 
                ? 'bg-amber-500 text-slate-900 border border-amber-600' // High visibility Gold
                : 'bg-slate-700 text-slate-300'
            }`}>
                {zone.timeframe}
            </span>
        </div>
        <div className="flex justify-between items-center">
            <span className="text-xs font-mono">{zone.top.toFixed(0)} - {zone.bottom.toFixed(0)}</span>
            {zone.trend === 'Bullish' ? <TrendingUp size={12}/> : <TrendingDown size={12}/>}
        </div>
        {zone.pattern === 'IFVG' && <span className="text-[10px] mt-1 italic opacity-75">Inversion (Flip)</span>}
        {zone.pattern === 'BOB' && <span className="text-[10px] mt-1 italic opacity-75">Breaker Block</span>}
    </div>
);

export const SmartMoneyTracker: React.FC = () => {
  const [zonesData, setZonesData] = useState<Record<string, SMCZone[]>>({});
  const [loading, setLoading] = useState(false);
  
  // Filters
  const [selectedTimeframe, setSelectedTimeframe] = useState<'ALL' | 'DAILY' | 'WEEKLY'>('ALL');
  const [selectedPattern, setSelectedPattern] = useState<SMCPatternType | 'ALL'>('ALL');

  const scanMarket = async () => {
    if (loading) return;
    setLoading(true);
    try {
        const results = await SmartMoneyLogic.scanAllIndices();
        setZonesData(results);
    } catch (e) {
        console.error("Scan failed", e);
    } finally {
        setLoading(false);
    }
  };

  useEffect(() => {
    scanMarket();
  }, []);

  return (
    <div className="space-y-6">
      {/* Header Area */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Layers className="text-purple-400" />
            Smart Money Tracker
          </h2>
          <p className="text-slate-400 text-sm">Automated detection of FVG, IFVG, OB, and BOB structures (Daily & Weekly).</p>
        </div>
        
        <button 
            onClick={scanMarket}
            disabled={loading}
            className={`flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-medium transition-colors ${loading ? 'opacity-75 cursor-not-allowed' : ''}`}
        >
            <RefreshCw size={18} className={loading ? 'animate-spin' : ''} />
            {loading ? 'Scanning...' : 'Scan Market'}
        </button>
      </div>

      {/* Control Panel / Filters */}
      <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700 flex flex-col md:flex-row gap-6">
        
        {/* Timeframe Filter */}
        <div className="flex flex-col gap-2">
            <span className="text-xs font-bold text-slate-500 uppercase flex items-center gap-1">
                <Clock size={12} /> Timeframe
            </span>
            <div className="flex bg-slate-900 rounded-lg p-1 border border-slate-700 w-fit">
                {(['ALL', 'DAILY', 'WEEKLY'] as const).map(tf => (
                    <button 
                        key={tf}
                        onClick={() => setSelectedTimeframe(tf)} 
                        className={`px-4 py-1.5 text-xs font-bold rounded-md transition-all ${
                            selectedTimeframe === tf 
                            ? 'bg-blue-600 text-white shadow-md' 
                            : 'text-slate-400 hover:text-white hover:bg-slate-800'
                        }`}
                    >
                        {tf}
                    </button>
                ))}
            </div>
        </div>

        {/* Pattern Filter */}
        <div className="flex flex-col gap-2">
            <span className="text-xs font-bold text-slate-500 uppercase flex items-center gap-1">
                <Filter size={12} /> Pattern Type
            </span>
            <div className="flex flex-wrap gap-2">
                {(['ALL', 'FVG', 'IFVG', 'OB', 'BOB'] as const).map(p => (
                    <button
                        key={p}
                        onClick={() => setSelectedPattern(p)}
                        className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition-all ${
                            selectedPattern === p 
                            ? 'bg-purple-600 border-purple-500 text-white shadow-md' 
                            : 'bg-slate-900 border-slate-700 text-slate-400 hover:border-slate-500'
                        }`}
                    >
                        {p}
                    </button>
                ))}
            </div>
        </div>

      </div>

      {/* Results Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {ALL_INDICES.map(index => {
              const zones = zonesData[index.id] || [];
              
              // Apply Filters
              const filteredZones = zones.filter(z => {
                  const tfMatch = selectedTimeframe === 'ALL' || z.timeframe === selectedTimeframe;
                  const patMatch = selectedPattern === 'ALL' || z.pattern === selectedPattern;
                  return tfMatch && patMatch;
              });

              // Hide cards with no data if a filter is active
              if (filteredZones.length === 0 && (selectedTimeframe !== 'ALL' || selectedPattern !== 'ALL')) return null;

              return (
                  <div key={index.id} className="bg-slate-800/50 border border-slate-700 rounded-xl overflow-hidden hover:border-slate-600 transition-colors">
                      <div className="p-4 bg-slate-800 border-b border-slate-700 flex justify-between items-center">
                          <div>
                              <h3 className="font-bold text-white">{index.symbol}</h3>
                              <span className="text-xs text-slate-500">{index.name}</span>
                          </div>
                          <div className="flex items-center gap-2">
                              {zones.length > 0 ? (
                                  <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                              ) : (
                                  <span className="flex h-2 w-2 rounded-full bg-slate-600"></span>
                              )}
                          </div>
                      </div>
                      
                      <div className="p-4 space-y-3 min-h-[150px]">
                          {loading && zones.length === 0 ? (
                              <div className="flex flex-col items-center justify-center h-full text-slate-500 gap-2 min-h-[120px]">
                                  <RefreshCw size={20} className="animate-spin opacity-50"/>
                                  <span className="text-xs">Analyzing structure...</span>
                              </div>
                          ) : filteredZones.length > 0 ? (
                              <div className="grid grid-cols-2 gap-2">
                                  {filteredZones.map((zone, idx) => (
                                      <PatternBadge key={idx} zone={zone} />
                                  ))}
                              </div>
                          ) : (
                              <div className="flex flex-col items-center justify-center h-full text-slate-600 py-6">
                                  <BoxSelect size={32} className="mb-2 opacity-20"/>
                                  <p className="text-xs">No {selectedPattern !== 'ALL' ? selectedPattern : ''} structures found</p>
                              </div>
                          )}
                      </div>
                      
                      {/* Footer Legend */}
                      <div className="bg-slate-900/50 p-2 border-t border-slate-700 flex gap-2 justify-center">
                          <span className="text-[10px] text-slate-500 flex items-center gap-1"><div className="w-1.5 h-1.5 bg-purple-500 rounded-full"></div> IFVG</span>
                          <span className="text-[10px] text-slate-500 flex items-center gap-1"><div className="w-1.5 h-1.5 bg-orange-500 rounded-full"></div> BOB</span>
                          <span className="text-[10px] text-slate-500 flex items-center gap-1"><div className="w-1.5 h-1.5 bg-amber-500 rounded-full"></div> Weekly</span>
                      </div>
                  </div>
              );
          })}
      </div>
      
      {/* Enhanced Concept Definitions */}
      <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700 mt-8">
          <h4 className="font-bold text-slate-300 mb-4 flex items-center gap-2 text-lg">
              <AlertCircle size={20} className="text-indigo-400" /> Concept Definitions
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                  <div className="p-4 bg-slate-900/50 rounded-lg border border-emerald-500/20 hover:border-emerald-500/40 transition-colors">
                      <strong className="text-emerald-400 block mb-2 text-sm uppercase tracking-wide">FVG (Fair Value Gap)</strong>
                      <p className="leading-relaxed text-sm text-slate-400">
                          A three-candle imbalance that represents inefficiency in price delivery. Price often returns to this area to rebalance liquidity, making it a high-probability reaction zone.
                      </p>
                  </div>
                  <div className="p-4 bg-slate-900/50 rounded-lg border border-purple-500/20 hover:border-purple-500/40 transition-colors">
                      <strong className="text-purple-400 block mb-2 text-sm uppercase tracking-wide">IFVG (Inversion FVG)</strong>
                      <p className="leading-relaxed text-sm text-slate-400">
                          A Fair Value Gap that fails when price aggressively breaks through it. After violation, the IFVG typically acts as a structural flip zone — converting support into resistance or vice-versa.
                      </p>
                  </div>
              </div>
              <div className="space-y-4">
                  <div className="p-4 bg-slate-900/50 rounded-lg border border-blue-500/20 hover:border-blue-500/40 transition-colors">
                      <strong className="text-blue-400 block mb-2 text-sm uppercase tracking-wide">OB (Order Block)</strong>
                      <p className="leading-relaxed text-sm text-slate-400">
                          The final opposite candle before a significant market displacement. It marks the origin of institutional orders and is considered a premium area for trend continuation or reversal.
                      </p>
                  </div>
                  <div className="p-4 bg-slate-900/50 rounded-lg border border-orange-500/20 hover:border-orange-500/40 transition-colors">
                      <strong className="text-orange-400 block mb-2 text-sm uppercase tracking-wide">BOB (Breaker Block)</strong>
                      <p className="leading-relaxed text-sm text-slate-400">
                          A failed Order Block that gets violated by price. After the break, the same zone transforms into a breaker — a reliable support/resistance flip zone with strong momentum backing.
                      </p>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
};
