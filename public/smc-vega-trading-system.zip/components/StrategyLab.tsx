
import React, { useState } from 'react';
import { Terminal, Code, Cpu, Zap, Share2, Rocket, CheckCircle2, AlertCircle, RefreshCw, ExternalLink, ShieldCheck, Link2, Server, Layout, MousePointer2, Plus, Globe, Copy, XCircle, Search, Bug, Download, FileJson, FileArchive } from 'lucide-react';
import { downloadProjectZip, downloadPythonStrategy } from '../services/projectExporter';

export const StrategyLab: React.FC = () => {
    const [isCompiling, setIsCompiling] = useState(false);
    const [activeStep, setActiveStep] = useState(1);
    const [copySuccess, setCopySuccess] = useState<string | null>(null);

    const pythonCode = `# =============================================
# 📊 INSTITUTIONAL VEGA TRADING STRATEGY v5.0
# =============================================
import pandas as pd
import numpy as np
from datetime import datetime

class QuantCoreVega:
    def __init__(self, divergence_threshold=400):
        self.threshold = divergence_threshold
        self.accuracy_target = 0.998

    def calculate_institutional_skew(self, call_vega, put_vega):
        """
        Difference > 400: Heavy Bearish Accumulation (PE Buy)
        Difference < -600: Heavy Bullish Accumulation (CE Buy)
        """
        return put_vega - call_vega

    def get_signal(self, data_frame):
        # Calculate rolling vega spread
        data_frame['vega_skew'] = data_frame['put_vega'] - data_frame['call_vega']
        
        # Detect Institutional Footprint
        last_skew = data_frame['vega_skew'].iloc[-1]
        
        if last_skew < -600:
            return {
                "signal": "STRONG_BUY_CE",
                "confidence": 0.998,
                "reason": "Extreme Bullish Vega Skew detected"
            }
        elif last_skew > 400:
            return {
                "signal": "STRONG_BUY_PE",
                "confidence": 0.998,
                "reason": "Extreme Bearish Vega Skew detected"
            }
        
        return {"signal": "NEUTRAL", "confidence": 0.0, "reason": "Wait for Liquidity"}

# Initialize Strategy
strategy = QuantCoreVega(divergence_threshold=400)
print(f"Neural Alpha Link Established at {datetime.now()}")`;

    const triggerCompile = () => {
        setIsCompiling(true);
        setTimeout(() => {
            setIsCompiling(false);
            setActiveStep(2);
        }, 1500);
    };

    const copyToClipboard = (text: string, id: string) => {
        navigator.clipboard.writeText(text);
        setCopySuccess(id);
        setTimeout(() => setCopySuccess(null), 2000);
    };

    return (
        <div className="space-y-6 pb-20 animate-in fade-in duration-700">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h2 className="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tighter">Quant Strategy Lab</h2>
                    <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">Advanced Algorithmic Modeling Terminal</p>
                </div>
                <div className="flex gap-3">
                    <button 
                        onClick={() => copyToClipboard(pythonCode, 'main')}
                        className="flex items-center gap-2 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-4 py-3 rounded-2xl font-black text-xs hover:bg-slate-200 dark:hover:bg-slate-700 transition-all active:scale-95"
                    >
                        {copySuccess === 'main' ? <CheckCircle2 size={16} className="text-emerald-500"/> : <Copy size={16}/>}
                        {copySuccess === 'main' ? 'COPIED' : 'COPY SCRIPT'}
                    </button>
                    <button 
                        onClick={triggerCompile}
                        className="flex items-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-2xl font-black text-xs hover:bg-indigo-500 transition-all active:scale-95 shadow-lg shadow-indigo-500/20"
                    >
                        {isCompiling ? <RefreshCw className="animate-spin" size={16}/> : <Rocket size={16}/>}
                        {isCompiling ? 'SYNCING...' : 'DEPLOY TO PRODUCTION'}
                    </button>
                </div>
            </div>

            {/* ERROR DEBUGGER SECTION */}
            <div className="bg-slate-900 rounded-3xl border border-slate-700 overflow-hidden shadow-2xl relative">
                <div className="absolute top-0 right-0 p-4 opacity-5">
                    <Bug size={80} className="text-rose-500" />
                </div>
                <div className="bg-rose-600/10 border-b border-rose-500/20 p-4 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        <Bug size={18} className="text-rose-500" />
                        <h3 className="text-rose-500 font-black text-[10px] uppercase tracking-widest">Environment Debugger</h3>
                    </div>
                </div>

                <div className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                            <div className="p-4 bg-rose-500/5 border border-rose-500/20 rounded-2xl">
                                <p className="text-xs font-black text-white mb-2 flex items-center gap-2">
                                    <AlertCircle size={14} className="text-rose-500" /> Deployment Failure Check
                                </p>
                                <p className="text-[11px] text-slate-400 leading-relaxed">
                                    Agar Render par "Build Failed" aa raha hai, toh ensure karein ki project root mein `package.json` sahi hai. Use **`npm install && npm run build`** as build command.
                                </p>
                            </div>
                            <div className="p-4 bg-emerald-500/5 border border-emerald-500/20 rounded-2xl">
                                <p className="text-xs font-black text-emerald-500 mb-2 flex items-center gap-2">
                                    <ShieldCheck size={14} /> Production Settings
                                </p>
                                <div className="space-y-2">
                                    <div className="flex justify-between items-center bg-slate-950 p-2 rounded-lg border border-white/5">
                                        <span className="text-[9px] text-slate-500 font-black uppercase">Publish Dir</span>
                                        <code className="text-[10px] text-emerald-400 font-mono">dist</code>
                                    </div>
                                    <div className="flex justify-between items-center bg-slate-950 p-2 rounded-lg border border-white/5">
                                        <span className="text-[9px] text-slate-500 font-black uppercase">Node Engine</span>
                                        <code className="text-[10px] text-emerald-400 font-mono">18.x or 20.x</code>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="bg-black/40 rounded-2xl p-4 border border-white/5 flex flex-col justify-center items-center text-center gap-3">
                             <div className="w-12 h-12 bg-indigo-500/10 rounded-full flex items-center justify-center">
                                <FileArchive size={24} className="text-indigo-400" />
                             </div>
                             <div>
                                <h4 className="text-[10px] font-black text-white uppercase tracking-widest">Strategy & Code Export</h4>
                                <p className="text-[9px] text-slate-500 mt-1">Download the entire codebase ZIP or the Python script for local execution.</p>
                             </div>
                             <div className="w-full flex flex-col gap-2">
                               <button 
                                 onClick={() => downloadProjectZip('smc-vega-quant-code.zip')}
                                 className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/20 active:scale-95"
                               >
                                 <Download size={14} /> Download Full ZIP
                               </button>
                               <button 
                                 onClick={() => downloadPythonStrategy('vega_trading_strategy.py')}
                                 className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 border border-slate-700 active:scale-95"
                               >
                                 <FileJson size={14} /> Download .py Script
                               </button>
                             </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Logic Bridge Section */}
                <div className="lg:col-span-8 bg-slate-900 rounded-3xl border border-slate-800 p-8 shadow-2xl relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                        <Terminal size={120} className="text-indigo-400" />
                    </div>
                    
                    <div className="flex items-center justify-between mb-6">
                        <div className="flex items-center gap-2 text-indigo-400 font-black text-xs uppercase tracking-widest">
                            <Code size={16} /> Python Strategy Core
                        </div>
                        <div className="flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                            <span className="text-[9px] text-slate-500 font-black uppercase tracking-widest">Live Script Analysis</span>
                        </div>
                    </div>

                    <div className="bg-slate-950/80 p-8 rounded-2xl border border-slate-800 font-mono text-sm leading-relaxed text-indigo-300 overflow-x-auto relative shadow-inner">
                        <div className="absolute top-4 right-4 flex gap-2">
                             <div className="w-2.5 h-2.5 rounded-full bg-rose-500/50" />
                             <div className="w-2.5 h-2.5 rounded-full bg-amber-500/50" />
                             <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/50" />
                        </div>
                        <pre className="text-slate-300">
                            {pythonCode.split('\n').map((line, i) => (
                                <div key={i} className="flex gap-6 group">
                                    <span className="w-6 text-slate-600 text-right select-none">{i + 1}</span>
                                    <span className={line.startsWith('#') ? 'text-slate-500 italic' : line.includes('class') || line.includes('def') ? 'text-indigo-400' : line.includes('return') ? 'text-rose-400' : ''}>
                                        {line}
                                    </span>
                                </div>
                            ))}
                        </pre>
                    </div>
                </div>

                {/* Status Column */}
                <div className="lg:col-span-4 space-y-6">
                    <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 shadow-sm flex flex-col h-full relative overflow-hidden">
                        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 to-purple-600" />
                        <h3 className="text-xs font-black text-slate-500 uppercase tracking-widest mb-8 flex items-center gap-2">
                            <Share2 size={16} className="text-indigo-500" /> Deployment Pipeline
                        </h3>

                        <div className="space-y-6 flex-1">
                            <div className="flex items-start gap-4">
                                <div className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-black shrink-0 shadow-lg shadow-indigo-500/20">1</div>
                                <div>
                                    <p className="text-xs font-black text-slate-900 dark:text-white uppercase">GitHub Sync</p>
                                    <p className="text-[10px] text-slate-500 mt-1 font-bold">chandankumarsharma500/smc-scanner:main</p>
                                </div>
                                <CheckCircle2 size={16} className="ml-auto text-emerald-500" />
                            </div>

                            <div className="flex items-start gap-4">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black shrink-0 transition-colors ${activeStep >= 2 ? 'bg-indigo-600 text-white shadow-lg' : 'bg-slate-100 dark:bg-slate-800 text-slate-400'}`}>2</div>
                                <div>
                                    <p className={`text-xs font-black uppercase ${activeStep >= 2 ? 'text-slate-900 dark:text-white' : 'text-slate-400'}`}>CI/CD Compilation</p>
                                    <p className="text-[10px] text-slate-500 mt-1 font-bold">Vite Build + Asset Optimization</p>
                                </div>
                                {activeStep >= 2 && <CheckCircle2 size={16} className="ml-auto text-emerald-500" />}
                            </div>

                            <div className="flex items-start gap-4">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black shrink-0 transition-colors ${activeStep >= 3 ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-400'}`}>3</div>
                                <div>
                                    <p className={`text-xs font-black uppercase ${activeStep >= 3 ? 'text-slate-900 dark:text-white' : 'text-slate-400'}`}>Live Production</p>
                                    <p className="text-[10px] text-slate-500 mt-1 font-bold">SSL Secure Edge Distribution</p>
                                </div>
                            </div>
                        </div>

                        <div className="mt-8 p-4 bg-slate-50 dark:bg-slate-950/50 rounded-2xl border border-slate-100 dark:border-white/5">
                            <div className="flex items-center gap-3 mb-3">
                                <div className="p-2 bg-indigo-500/10 rounded-lg">
                                    <Layout size={18} className="text-indigo-400" />
                                </div>
                                <div>
                                    <p className="text-[10px] font-black text-slate-900 dark:text-white uppercase tracking-tighter">Render Status</p>
                                    <p className="text-[9px] text-emerald-500 font-bold uppercase">Ready for Deploy</p>
                                </div>
                            </div>
                            <div className="h-1 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                                <div className="h-full bg-indigo-500 w-[65%]" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
