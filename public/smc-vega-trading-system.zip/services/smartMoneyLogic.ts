import { Candle, SMCZone, TimeFrame, Trend, SMCPatternType } from '../types';
import { ALL_INDICES } from './dhanService';
import { yahooFinanceService } from './yahooFinanceService';
import { twelveDataService } from './twelveDataService';

export class SmartMoneyLogic {
  static generateMockCandles(startPrice: number, count: number, volatility: number = 0.02): Candle[] {
    const candles: Candle[] = [];
    let currentPrice = startPrice;
    for (let i = 0; i < count; i++) {
      const isUp = Math.random() > 0.48; 
      const move = currentPrice * volatility * (Math.random() * 3);
      const open = currentPrice;
      const close = isUp ? open + move : open - move;
      candles.push({
        time: new Date(Date.now() - (count - i) * 86400000).toISOString().split('T')[0], 
        open, high: Math.max(open, close) + 5, low: Math.min(open, close) - 5, close
      });
      currentPrice = close;
    }
    return candles;
  }

  static detectPatterns(symbol: string, candles: Candle[], timeframe: TimeFrame): SMCZone[] {
    const zones: SMCZone[] = [];
    const s = [...candles].sort((a,b) => new Date(a.time).getTime() - new Date(b.time).getTime());
    const len = s.length;
    if (len < 10) return [];
    const latest = s[len-1].close;

    for (let i = len - 2; i > 2; i--) {
      const c = s[i], p = s[i-1], n = s[i+1];
      
      // 1. FVG & IFVG Logic
      if (p.high < n.low) { // Bullish Gap
        const isBroken = latest < p.high;
        zones.push({
          id: `${symbol}-FVG-B-${i}`, symbol, timeframe, candleTime: c.time,
          pattern: isBroken ? 'IFVG' : 'FVG', trend: isBroken ? 'Bearish' : 'Bullish',
          top: n.low, bottom: p.high, isMitigated: isBroken
        });
      }
      if (p.low > n.high) { // Bearish Gap
        const isBroken = latest > p.low;
        zones.push({
          id: `${symbol}-FVG-S-${i}`, symbol, timeframe, candleTime: c.time,
          pattern: isBroken ? 'IFVG' : 'FVG', trend: isBroken ? 'Bullish' : 'Bearish',
          top: p.low, bottom: n.high, isMitigated: isBroken
        });
      }

      // 2. OB & BOB Logic
      if (c.close < c.open && n.close > n.open && n.close > c.high) { // Bullish OB
        const isBroken = latest < c.low;
        zones.push({
          id: `${symbol}-OB-B-${i}`, symbol, timeframe, candleTime: c.time,
          pattern: isBroken ? 'BOB' : 'OB', trend: isBroken ? 'Bearish' : 'Bullish',
          top: c.high, bottom: c.low, isMitigated: isBroken
        });
      }
      if (c.close > c.open && n.close < n.open && n.close < c.low) { // Bearish OB
        const isBroken = latest > c.high;
        zones.push({
          id: `${symbol}-OB-S-${i}`, symbol, timeframe, candleTime: c.time,
          pattern: isBroken ? 'BOB' : 'OB', trend: isBroken ? 'Bullish' : 'Bearish',
          top: c.high, bottom: c.low, isMitigated: isBroken
        });
      }
    }
    return zones.sort((a,b) => b.candleTime.localeCompare(a.candleTime)).slice(0, 30);
  }

  static async scanAllIndices(): Promise<Record<string, SMCZone[]>> {
    const results: Record<string, SMCZone[]> = {};
    for (const index of ALL_INDICES) {
      try {
        const daily = await twelveDataService.getCandles(index.id, 'DAILY');
        const dZones = this.detectPatterns(index.symbol, daily.length ? daily : this.generateMockCandles(22000, 40), 'DAILY');
        results[index.id] = dZones;
      } catch (e) { console.warn(e); }
    }
    return results;
  }
}