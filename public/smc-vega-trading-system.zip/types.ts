
export type Trend = 'Bullish' | 'Bearish';
export type SignalType = 'BUY' | 'SELL' | 'HOLD';

export interface MarketDataPoint {
  time: string;
  timestamp: number;
  callVega: number;
  putVega: number;
  difference: number;
  trend: Trend;
}

export interface TradingSignal {
  type: SignalType;
  strength: 'STRONG' | 'MODERATE' | 'NONE';
  tag: 'SNIPER' | 'INSTITUTIONAL' | 'SCALP';
  confidence: number;
  reason: string;
  action: string;
  stopLoss: string;
  target: string;
  timestamp: number;
  confluence?: string[];
}

export interface IndexDefinition {
  id: string;
  symbol: string;
  exchange: 'NSE' | 'BSE' | 'GLOBAL' | 'CRYPTO';
  name: string;
}

export interface IndexMarketData {
  definition: IndexDefinition;
  price: number;
  change: number;
  percentChange: number;
  callVega: number;
  putVega: number;
  difference: number;
  trend: Trend;
  source?: string;
}

export interface GoogleSheetConfig {
  enabled: boolean;
  webhookUrl: string;
  sheetName: string;
}

export interface SMCZone {
    id: string;
    symbol: string;
    pattern: 'FVG' | 'IFVG' | 'OB' | 'BOB';
    trend: Trend;
    timeframe: 'DAILY' | 'WEEKLY' | 'INTRADAY';
    top: number;
    bottom: number;
    candleTime: string;
    isMitigated: boolean;
}

export interface BrokerProfile {
  name: string;
  email: string;
  client_id: string;
  userType: string;
  broker?: 'DHAN' | 'UPSTOX' | 'ZERODHA';
}

export interface OrderRequest {
  tradingSymbol: string;
  transactionType: 'BUY' | 'SELL';
  orderType: 'MARKET' | 'LIMIT';
  quantity: number;
  productType: 'INTRADAY' | 'DELIVERY';
  // Added optional property for broker specific segments
  exchangeSegment?: string;
}

// Added missing types to resolve compilation errors
export interface BacktestResult {
  data: MarketDataPoint;
  signal: TradingSignal;
}

export type DhanEnv = 'PRODUCTION' | 'SANDBOX';

export interface DhanConfig {
  clientId: string;
  accessToken?: string;
  environment: DhanEnv;
}

export interface DhanProfile {
  name: string;
  email: string;
  client_id: string;
  userType: string;
  broker: 'DHAN';
}

export interface DhanHolding {
  tradingSymbol: string;
  quantity: number;
  averagePrice: number;
  lastPrice: number;
  pnl: number;
  exchange: string;
}

export interface UpstoxConfig {
  apiKey: string;
  accessToken: string;
  apiSecret?: string;
  redirectUri?: string;
}

export interface ZerodhaConfig {
  apiKey: string;
  apiSecret: string;
  accessToken: string;
}

export interface BrokerHolding {
  tradingSymbol: string;
  quantity: number;
  averagePrice: number;
  lastPrice: number;
  pnl: number;
  exchange: string;
}

export type BrokerId = 'DHAN' | 'UPSTOX' | 'ZERODHA';

export interface TwelveDataConfig {
  apiKey: string;
  symbol: string;
  interval?: string;
}

export interface Candle {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
}

export interface MobileBackendConfig {
  enabled: boolean;
  cloudFunctionUrl: string;
  authKey?: string;
}

export type TimeFrame = 'DAILY' | 'WEEKLY' | 'INTRADAY';

export type SMCPatternType = 'FVG' | 'IFVG' | 'OB' | 'BOB';

export interface GlobalAssetData {
  id: string;
  symbol: string;
  name: string;
  category: 'INDEX' | 'CRYPTO';
  price: number;
  change: number;
  percentChange: number;
  trend: Trend;
}

// CRT (Candle Range Theory) Strategy Types
export type CRTTimeframe = 'MONTHLY' | 'WEEKLY' | 'DAILY' | '4H' | '1H';

export type CRTRangeState = 
  | 'INSIDE_RANGE' 
  | 'HIGH_SWEPT' 
  | 'LOW_SWEPT' 
  | 'EXPANDING_BULLISH' 
  | 'EXPANDING_BEARISH';

export interface CRTCandleMarking {
  timeframe: CRTTimeframe;
  periodLabel: string; // e.g. "Current Month", "Current Week", "Current Day", "Current 4H", "Current 1H"
  open: number;
  high: number;
  low: number;
  close: number;
  equilibrium: number; // (high + low) / 2
  rangeSpan: number;   // high - low
  // Levels
  highLabel: string;  // e.g. PMH, PWH, PDH, P4H_H, P1H_H
  lowLabel: string;   // e.g. PML, PWL, PDL, P4H_L, P1H_L
  openLabel: string;  // e.g. MO, WO, DO, 4HO, 1HO
  // State analysis relative to current price
  currentPrice: number;
  isHighSwept: boolean;
  isLowSwept: boolean;
  zone: 'PREMIUM' | 'DISCOUNT' | 'EQUILIBRIUM';
  state: CRTRangeState;
  bias: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  target1: number; // 50% EQ
  target2: number; // Range opposite extreme
  invalidationLevel: number;
}

export interface CRTMultiTFAnalysis {
  symbol: string;
  currentPrice: number;
  markings: Record<CRTTimeframe, CRTCandleMarking>;
  confluentBias: 'STRONG_BULLISH' | 'BULLISH' | 'NEUTRAL' | 'BEARISH' | 'STRONG_BEARISH';
  activeSignals: Array<{
    timeframe: CRTTimeframe;
    type: 'BUY_SWEEP' | 'SELL_SWEEP' | 'EQ_RETEST_BUY' | 'EQ_RETEST_SELL';
    title: string;
    description: string;
    entry: number;
    stopLoss: number;
    tp1: number;
    tp2: number;
    riskReward: number;
    confidence: number;
  }>;
  lastUpdated: string;
}
